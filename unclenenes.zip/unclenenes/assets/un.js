( function () {
	const cfg = window.UN || {};
	const menu = cfg.menu || {};
	const fmt = ( n ) => 'KSh ' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s == null ? '' : s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const waUrl = ( text ) => 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( text );
	const HI = 'Hi Uncle Nene\'s, ';
	const ls = {
		get: ( k ) => {
			try {
				return localStorage.getItem( k );
			} catch ( e ) {
				return null;
			}
		},
		set: ( k, v ) => {
			try {
				localStorage.setItem( k, v );
			} catch ( e ) {}
		},
	};
	const O = cfg.opts || { extras: {}, sides: {}, dips: {}, double: 0 };

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.un-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'un-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		// An open dialog sits in the top layer: show the toast inside it so it isn't hidden.
		const open = document.querySelector( 'dialog[open]' );
		if ( box.parentNode !== ( open || document.body ) ) ( open || document.body ).appendChild( box );
		const t = document.createElement( 'div' );
		t.className = 'un-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 4200 );
		setTimeout( () => t.remove(), 4700 );
	}
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your order · <a href="' + esc( cfg.checkout ) + '">Checkout</a>' ) );

	/* How you want it: delivery, pickup or dine-in ------------------------ */
	const MODES = { delivery: 'Delivery', pickup: 'Pickup', dinein: 'Dine-in at Garden Estate' };
	const getMode = () => ( MODES[ ls.get( 'un-mode' ) ] ? ls.get( 'un-mode' ) : 'delivery' );
	function paintMode() {
		const m = getMode();
		$$( '[data-un-mode]' ).forEach( ( b ) => b.setAttribute( 'aria-pressed', b.dataset.unMode === m ? 'true' : 'false' ) );
		$$( '[data-un-mode-note]' ).forEach( ( el ) => {
			el.innerHTML = {
				delivery: '🛵 <strong>Delivery</strong> by our riders from Ngummo or Garden Estate, from KSh 200 (free with the Patty Party Pack). Order before the 12:30 lunch rush and it reaches you fastest.',
				pickup: '🛍 <strong>Free pickup</strong> at our Ngummo window on Mbagathi Rd, or the Garden Estate counter at Amani Food Court. You choose the kitchen at checkout.',
				dinein: '🍽 <strong>Dine-in at Amani Food Court, Garden Estate:</strong> walk in, no booking needed. Seating, games and colouring for the kids, plus shakes, lemonades and hot drinks made fresh.',
			}[ m ];
		} );
		document.documentElement.dataset.unMode = m;
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-un-mode]' );
		if ( ! b ) return;
		ls.set( 'un-mode', b.dataset.unMode );
		paintMode();
	} );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart; tell it to reload.
	async function refreshMiniCart( cart ) {
		try {
			const { store: iStore } = await import( '@wordpress/interactivity' );
			const wc = iStore( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}
	async function addItem( id, quantity, un ) {
		if ( ! nonce ) await getCart();
		const res = await fetch( cfg.store + 'cart/add-item', {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json', Nonce: nonce },
			body: JSON.stringify( { id: Number( id ), quantity: quantity || 1, un: un || {} } ),
		} );
		const cart = await res.json();
		if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
		await refreshMiniCart( cart );
		document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
		setTimeout( () => refreshMiniCart(), 900 );
		return cart;
	}
	const addedMsg = ( name, qty ) => '✓ ' + ( qty > 1 ? qty + ' × ' : '' ) + esc( name ) + ' added · <a href="' + esc( cfg.checkout ) + '">Checkout</a>';
	// Shakes, lemonades and hot drinks are made at Garden Estate only.
	const dineinWarn = ( d ) => ( d.dinein && getMode() === 'delivery' ? ' · <strong>Garden Estate only:</strong> choose Pickup → Garden Estate at checkout, or eat in.' : '' );

	// Quick "Add": the first choice, no extras.
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-un-quick]' );
		if ( ! b ) return;
		e.preventDefault();
		const d = menu[ b.dataset.unQuick ];
		if ( ! d ) return;
		b.disabled = true;
		b.classList.add( 'is-busy' );
		try {
			const choice = d.choices && d.choices[ 0 ];
			await addItem( choice ? choice.id : d.id, 1, {} );
			b.classList.add( 'is-done' );
			b.textContent = '✓';
			setTimeout( () => {
				b.classList.remove( 'is-done' );
				b.textContent = 'Add';
			}, 1600 );
			toast( addedMsg( d.name + ( choice ? ' (' + choice.label + ')' : '' ), 1 ) + ( d.opts.length || d.choices.length > 1 ? ' · <a href="#" data-un-dish="' + d.id + '">' + ( d.opts.indexOf( 'double' ) > -1 ? 'Make it a double?' : 'Customise' ) + '</a>' : '' ) + dineinWarn( d ) );
		} catch ( err ) {
			toast( esc( err.message || 'Could not add. Please try again.' ) );
		} finally {
			b.disabled = false;
			b.classList.remove( 'is-busy' );
		}
	} );

	/* WhatsApp ------------------------------------------------------------ */
	const modeLines = () => {
		const m = getMode();
		return m === 'delivery' ? [ 'Deliver to (building / estate, landmark): ' ] : m === 'pickup' ? [ 'Pickup at (Ngummo / Garden Estate), time: ' ] : [ 'Dine-in at Garden Estate, time: ' ];
	};
	document.addEventListener( 'click', ( e ) => {
		const a = e.target.closest( '[data-un-wa-item]' );
		if ( ! a ) return;
		const d = menu[ a.dataset.unWaItem ];
		if ( ! d ) return;
		a.href = waUrl( [ HI + 'I\'d like to order (' + MODES[ getMode() ] + '):', '• 1 × ' + d.name + ( d.choices.length ? ' (' + d.choices[ 0 ].label + ')' : '' ) + ' – ' + fmt( d.price ), ...modeLines(), 'Name: ' ].join( '\n' ) );
	} );
	const itemLine = ( it ) => {
		const opts = ( it.variation || [] ).map( ( v ) => plain( v.value ) ).join( ', ' );
		const extra = ( it.item_data || [] ).map( ( d ) => plain( d.key || d.name ) + ': ' + plain( d.value || d.display ) ).join( ' · ' );
		return '• ' + it.quantity + ' × ' + plain( it.name ) + ( opts ? ' (' + opts + ')' : '' ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) + ( extra ? '\n   ' + extra : '' );
	};
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-un-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab inside the click so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your order is empty.' );
				return;
			}
			const lines = [ HI + 'I\'d like to order (' + MODES[ getMode() ] + '):' ];
			cart.items.forEach( ( it ) => lines.push( itemLine( it ) ) );
			lines.push( 'Food total: ' + fmt( money( cart.totals.total_items, cart.totals ) ), ...modeLines(), 'Name: ', 'Pay by: M-Pesa / cash' );
			const url = waUrl( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your order. Please try again.' );
		}
	} );

	/* Dish pop-up: photos, kitchen clip, options, allergens -------------- */
	const dlg = document.getElementById( 'un-dish' );
	function dishTotal( state ) {
		const d = state.d;
		const choice = d.choices.find( ( c ) => String( c.id ) === String( state.choice ) );
		let unit = choice ? choice.price : d.price;
		if ( state.double ) unit += O.double;
		( state.extras || [] ).forEach( ( k ) => ( unit += O.extras[ k ][ 1 ] ) );
		( state.sides || [] ).forEach( ( k ) => ( unit += O.sides[ k ][ 1 ] ) );
		return { unit, total: unit * state.qty, choice };
	}
	const checks = ( name, list, legend ) => '<fieldset class="un-opt"><legend>' + legend + '</legend><div class="un-checks">' + Object.keys( list ).map( ( k ) => '<label><input type="checkbox" name="' + name + '" value="' + k + '"><span>' + esc( list[ k ][ 0 ] ) + '</span><b>+' + fmt( list[ k ][ 1 ] ) + '</b></label>' ).join( '' ) + '</div></fieldset>';
	function openDish( id ) {
		const d = menu[ id ];
		if ( ! d || ! dlg || ! dlg.showModal ) return false;
		const body = dlg.querySelector( '[data-un-dish-body]' );
		const has = ( o ) => d.opts.indexOf( o ) > -1;
		const state = { d, qty: 1, choice: d.choices.length ? d.choices[ 0 ].id : '', double: false, extras: [], sides: [], dip: Object.keys( O.dips )[ 0 ], note: '' };
		const imgs = d.imgs.length ? d.imgs : [ '' ];
		const thumbs = imgs.map( ( src, i ) => '<button type="button" data-un-dish-img="' + i + '"' + ( i ? '' : ' class="is-on"' ) + '><img src="' + esc( src ) + '" alt=""></button>' ).join( '' ) +
			( d.clip ? '<button type="button" class="un-dish__clipbtn" data-un-dish-clip><span>▶</span>See it made</button>' : '' );
		const base = d.choices.length ? Math.min( ...d.choices.map( ( c ) => c.price ) ) : d.price;
		const choiceHtml = d.choices.length ? '<fieldset class="un-opt"><legend>' + esc( d.choice ) + '</legend><div class="un-pills">' + d.choices.map( ( c, i ) => '<label><input type="radio" name="choice" value="' + c.id + '"' + ( i ? '' : ' checked' ) + '><span>' + esc( c.label ) + ( c.price > base ? ' <b>+' + fmt( c.price - base ) + '</b>' : '' ) + '</span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const doubleHtml = has( 'double' ) ? '<fieldset class="un-opt"><legend>Size</legend><div class="un-pills"><label><input type="radio" name="double" value="" checked><span>Single</span></label><label><input type="radio" name="double" value="1"><span>Make it a double <b>+' + fmt( O.double ) + '</b></span></label></div></fieldset>' : '';
		const dipHtml = has( 'dip' ) ? '<fieldset class="un-opt"><legend>Your dip <em>included</em></legend><div class="un-pills">' + Object.keys( O.dips ).map( ( k, i ) => '<label><input type="radio" name="dip" value="' + k + '"' + ( i ? '' : ' checked' ) + '><span>' + esc( O.dips[ k ] ) + '</span></label>' ).join( '' ) + '</div></fieldset>' : '';
		const extrasHtml = has( 'extras' ) ? checks( 'extras', O.extras, 'Add-ons' ) : '';
		const sidesHtml = has( 'sides' ) ? checks( 'sides', O.sides, 'Add a side' ) : '';
		const dinein = d.dinein ? '<p class="un-alert">Made at Amani Food Court, Garden Estate: for dine-in or Garden Estate pickup, not delivery.</p>' : '';
		body.innerHTML =
			'<form class="un-dish__grid" data-un-dish-form>' +
			'<div class="un-dish__media"><div class="un-dish__main">' + imgs.map( ( src, i ) => '<img src="' + esc( src ) + '" alt="' + ( i ? '' : esc( d.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' ) +
			( d.clip ? '<video data-un-dish-video src="' + esc( d.clip ) + '" muted loop playsinline preload="none" hidden></video>' : '' ) + ( d.badge ? '<span class="un-card__badge">' + esc( d.badge ) + '</span>' : '' ) + '</div>' +
			'<div class="un-dish__thumbs">' + thumbs + '</div>' + ( d.drawn ? '<p class="un-note">The picture is a drawing, not a photo.</p>' : '' ) + '</div>' +
			'<div class="un-dish__info">' +
			'<p class="un-eyebrow">' + esc( d.catName ) + '</p><p class="un-dish__line">' + esc( d.line ) + '</p>' +
			'<h2>' + esc( d.name ) + '</h2>' +
			'<div class="un-tags">' + ( d.likes ? '<span class="un-tag">' + esc( d.likes ) + '</span>' : '' ) + ( d.portion ? '<span class="un-tag un-tag--line">' + esc( d.portion ) + '</span>' : '' ) + '</div>' +
			'<p class="un-dish__desc">' + esc( d.short ) + '</p>' + dinein +
			choiceHtml + doubleHtml + dipHtml + extrasHtml + sidesHtml +
			'<label class="un-opt un-opt--note">Requests<input type="text" name="note" maxlength="160" placeholder="e.g. no onions, sauce on the side, Fanta"></label>' +
			'<details class="un-dish__sheet"><summary>What\'s in it &amp; allergens</summary><div><p><strong>What\'s in it:</strong> ' + esc( d.ingr.join( ', ' ) ) + '</p><p><strong>Allergens:</strong> ' + esc( d.allergens.length ? d.allergens.join( ', ' ) : 'none of the common ones' ) + '</p><p class="un-small">Our kitchen handles wheat, egg, milk, sesame and fish. Tell us about any allergy.</p></div></details>' +
			'<div class="un-dish__buy"><div class="un-qty"><button type="button" data-un-qty="-1" aria-label="One less">−</button><output data-un-qty-out>1</output><button type="button" data-un-qty="1" aria-label="One more">+</button></div>' +
			'<button type="submit" class="wp-element-button un-dish__add"' + ( d.stock ? '' : ' disabled' ) + '>' + ( d.stock ? 'Add to order · <span data-un-dish-total></span>' : 'Sold out today<span data-un-dish-total hidden></span>' ) + '</button></div>' +
			'<div class="un-dish__links"><a class="un-wa-order" data-un-dish-wa href="#" target="_blank" rel="noopener">Instant WhatsApp order</a><a class="un-link" href="' + esc( d.url ) + '">Full details →</a></div>' +
			'</div></form>';
		const form = body.querySelector( 'form' );
		const update = () => {
			const f = new FormData( form );
			state.choice = f.get( 'choice' ) || '';
			state.double = !! f.get( 'double' );
			state.extras = f.getAll( 'extras' );
			state.sides = f.getAll( 'sides' );
			state.dip = f.get( 'dip' ) || '';
			state.note = String( f.get( 'note' ) || '' ).trim();
			const t = dishTotal( state );
			body.querySelector( '[data-un-dish-total]' ).textContent = fmt( t.total );
			body.querySelector( '[data-un-qty-out]' ).textContent = state.qty;
			const opts = [];
			if ( state.double ) opts.push( 'Double' );
			state.extras.forEach( ( k ) => opts.push( '+ ' + O.extras[ k ][ 0 ] ) );
			state.sides.forEach( ( k ) => opts.push( '+ ' + O.sides[ k ][ 0 ] ) );
			if ( has( 'dip' ) && state.dip ) opts.push( 'Dip: ' + O.dips[ state.dip ] );
			if ( state.note ) opts.push( 'Note: ' + state.note );
			body.querySelector( '[data-un-dish-wa]' ).href = waUrl( [ HI + 'I\'d like to order (' + MODES[ getMode() ] + '):', '• ' + state.qty + ' × ' + d.name + ( t.choice ? ' (' + t.choice.label + ')' : '' ) + ' – ' + fmt( t.total ), ...( opts.length ? [ '   ' + opts.join( ' · ' ) ] : [] ), ...modeLines(), 'Name: ' ].join( '\n' ) );
			$$( '.un-pills label, .un-checks label', form ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
		};
		form.addEventListener( 'change', update );
		form.addEventListener( 'input', update );
		form.addEventListener( 'click', ( e ) => {
			const q = e.target.closest( '[data-un-qty]' );
			if ( q ) {
				state.qty = Math.max( 1, Math.min( 20, state.qty + Number( q.dataset.unQty ) ) );
				update();
			}
			const ti = e.target.closest( '[data-un-dish-img]' );
			const main = body.querySelector( '.un-dish__main' );
			const video = body.querySelector( '[data-un-dish-video]' );
			if ( ti ) {
				$$( 'img', main ).forEach( ( im, i ) => ( im.hidden = i !== Number( ti.dataset.unDishImg ) ) );
				if ( video ) {
					video.hidden = true;
					video.pause();
				}
				$$( '.un-dish__thumbs button', body ).forEach( ( b ) => b.classList.toggle( 'is-on', b === ti ) );
			}
			if ( e.target.closest( '[data-un-dish-clip]' ) && video ) {
				$$( 'img', main ).forEach( ( im ) => ( im.hidden = true ) );
				video.hidden = false;
				video.play().catch( () => {} );
				$$( '.un-dish__thumbs button', body ).forEach( ( b ) => b.classList.toggle( 'is-on', b.hasAttribute( 'data-un-dish-clip' ) ) );
			}
		} );
		form.addEventListener( 'submit', async ( e ) => {
			e.preventDefault();
			const btn = form.querySelector( '.un-dish__add' );
			btn.disabled = true;
			try {
				const un = { double: state.double ? 1 : 0, extras: state.extras, sides: state.sides, dip: state.dip, note: state.note };
				await addItem( state.choice || d.id, state.qty, un );
				dlg.close();
				const t = dishTotal( state );
				toast( addedMsg( d.name + ( t.choice ? ' (' + t.choice.label + ')' : '' ) + ( state.double ? ', double' : '' ), state.qty ) + dineinWarn( d ) );
			} catch ( err ) {
				toast( esc( err.message || 'Could not add. Please try again.' ) );
			} finally {
				btn.disabled = false;
			}
		} );
		update();
		dlg.showModal();
		return true;
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-un-dish]' );
		if ( ! b || e.ctrlKey || e.metaKey || e.shiftKey ) return;
		if ( openDish( b.dataset.unDish ) ) e.preventDefault();
	} );
	if ( dlg ) dlg.addEventListener( 'close', () => $$( 'video', dlg ).forEach( ( v ) => v.pause() ) );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.un-dialog' ) ) e.target.close();
	} );

	/* Menu hub: live filters --------------------------------------------- */
	const MAX = 2000;
	function initMenu() {
		const root = document.querySelector( '[data-un-menu]' );
		if ( ! root ) return;
		const cards = $$( '[data-un-card]', root );
		const params = new URLSearchParams( location.search );
		const hash = location.hash.replace( '#', '' );
		const state = {
			q: params.get( 'q' ) || '',
			cat: params.get( 'cat' ) || ( $$( '[data-un-cat="' + hash + '"]', root ).length ? hash : root.dataset.startCat || '' ),
			diets: new Set( ( params.get( 'diet' ) || '' ).split( ',' ).filter( Boolean ) ),
			max: Number( params.get( 'max' ) ) || MAX,
			sort: '',
		};
		const q = root.querySelector( '[data-un-q]' );
		const range = root.querySelector( '[data-un-price]' );
		const priceLabel = root.querySelector( '[data-un-price-label]' );
		const count = root.querySelector( '[data-un-count]' );
		const empty = root.querySelector( '[data-un-empty]' );
		const active = root.querySelector( '[data-un-active]' );
		const more = root.querySelector( '[data-un-more]' );
		q.value = state.q;
		range.value = state.max;
		if ( state.diets.size || state.max < MAX ) more.open = true;
		const matches = ( c ) => {
			const d = c.dataset;
			const tags = d.tags.split( ' ' );
			if ( state.cat && d.cat !== state.cat ) return false;
			if ( state.q && d.name.indexOf( state.q.toLowerCase().trim() ) === -1 ) return false;
			if ( state.max < MAX && Number( d.price ) > state.max ) return false;
			// Loaded fries come in plain styles too, so "no bacon" / "cheesy" only rule out what can't be had that way.
			const flexible = d.cat === 'loaded-fries' || d.cat === 'family';
			for ( const t of state.diets ) {
				if ( t === 'no-bacon' ) {
					if ( tags.indexOf( 'bacon' ) > -1 && ! flexible ) return false;
				} else if ( tags.indexOf( t ) === -1 ) return false;
			}
			return true;
		};
		// Home page: only the most-loved dishes until the visitor searches or filters.
		const previewMore = root.querySelector( '[data-un-preview-more]' );
		const apply = () => {
			const preview = root.hasAttribute( 'data-un-preview' ) && ! state.q && ! state.cat && ! state.diets.size && state.max >= MAX && ! state.showAll;
			root.classList.toggle( 'is-preview', preview );
			if ( previewMore ) previewMore.hidden = ! preview;
			let n = 0;
			cards.forEach( ( c ) => {
				const on = preview ? c.hasAttribute( 'data-featured' ) : matches( c );
				c.hidden = ! on;
				if ( on ) n++;
			} );
			$$( '[data-un-sec]', root ).forEach( ( s ) => ( s.hidden = ! $$( '[data-un-card]:not([hidden])', s ).length ) );
			// Sorting: inside each section.
			$$( '.un-grid', root ).forEach( ( g ) => {
				const list = $$( '[data-un-card]', g );
				const key = { popular: ( c ) => ( c.hasAttribute( 'data-featured' ) ? 0 : 1 ) * 1000 + Number( c.dataset.order ), low: ( c ) => Number( c.dataset.price ), high: ( c ) => -Number( c.dataset.price ) }[ state.sort ] || ( ( c ) => Number( c.dataset.order ) );
				list.sort( ( a, b ) => key( a ) - key( b ) ).forEach( ( c ) => g.appendChild( c ) );
			} );
			count.textContent = preview ? 'The ' + n + ' everyone orders · search or filter to see all ' + cards.length : n + ( n === 1 ? ' item' : ' items' ) + ( state.cat ? ' in ' + root.querySelector( '[data-un-cat="' + state.cat + '"]' ).textContent : '' );
			empty.hidden = n > 0;
			$$( '[data-un-cat]', root ).forEach( ( b ) => b.classList.toggle( 'is-on', ! preview && b.dataset.unCat === state.cat ) );
			$$( '[data-un-diet]', root ).forEach( ( b ) => b.setAttribute( 'aria-pressed', state.diets.has( b.dataset.unDiet ) ? 'true' : 'false' ) );
			priceLabel.textContent = state.max >= MAX ? 'Any price' : 'Up to ' + fmt( state.max );
			const nActive = state.diets.size + ( state.max < MAX ? 1 : 0 );
			active.textContent = nActive ? nActive + ' on' : '';
			$$( '[data-un-clear]', root ).forEach( ( b ) => ( b.hidden = ! ( nActive || state.q || state.cat ) && ! b.closest( '[data-un-empty]' ) ) );
		};
		root.addEventListener( 'click', ( e ) => {
			const t = e.target.closest( '[data-un-cat],[data-un-diet],[data-un-clear]' );
			if ( ! t ) return;
			if ( t.hasAttribute( 'data-un-cat' ) ) {
				state.cat = t.dataset.unCat;
				if ( ! state.cat ) state.showAll = true; // "All" opens the whole menu, even on the home page
				if ( state.cat ) history.replaceState( null, '', '#' + state.cat );
			}
			if ( t.hasAttribute( 'data-un-diet' ) ) state.diets[ state.diets.has( t.dataset.unDiet ) ? 'delete' : 'add' ]( t.dataset.unDiet );
			if ( t.hasAttribute( 'data-un-clear' ) ) {
				Object.assign( state, { q: '', cat: '', max: MAX, showAll: false } );
				state.diets.clear();
				q.value = '';
				range.value = MAX;
			}
			apply();
		} );
		q.addEventListener( 'input', () => {
			state.q = q.value;
			apply();
		} );
		range.addEventListener( 'input', () => {
			state.max = Number( range.value );
			apply();
		} );
		root.querySelector( '[data-un-sort]' ).addEventListener( 'change', ( e ) => {
			state.sort = e.target.value;
			apply();
		} );
		// The header search filters this menu live instead of reloading.
		$$( '[data-un-search-form]' ).forEach( ( f ) => f.addEventListener( 'submit', ( e ) => {
			e.preventDefault();
			const fd = new FormData( f );
			state.q = String( fd.get( 'q' ) || '' );
			q.value = state.q;
			if ( fd.get( 'diet' ) ) state.diets = new Set( [ fd.get( 'diet' ) ] );
			apply();
			root.scrollIntoView( { behavior: 'smooth' } );
		} ) );
		apply();
		if ( state.cat || state.q || params.toString() ) setTimeout( () => root.scrollIntoView( { behavior: 'smooth' } ), 200 );
	}

	/* Card photo sliders: dots follow the swipe -------------------------- */
	function initSlides() {
		$$( '.un-card__slides' ).forEach( ( s ) => {
			const dots = $$( 'i', s.parentNode.querySelector( '.un-card__dots' ) || document.createElement( 'div' ) );
			if ( ! dots.length ) return;
			dots[ 0 ].classList.add( 'is-on' );
			s.addEventListener( 'scroll', () => {
				const i = Math.round( s.scrollLeft / s.clientWidth );
				dots.forEach( ( d, n ) => d.classList.toggle( 'is-on', n === i ) );
			}, { passive: true } );
		} );
	}

	/* Group orders, VIP Club --------------------------------------------- */
	function initRequests() {
		$$( '[data-un-request]' ).forEach( ( form ) => {
			form.addEventListener( 'submit', async ( e ) => {
				e.preventDefault();
				if ( ! form.reportValidity() ) return;
				const type = form.dataset.unRequest;
				const fd = new FormData( form );
				const body = { type };
				fd.forEach( ( v, k ) => ( body[ k ] = v ) );
				const btn = form.querySelector( '[type=submit]' );
				const label = btn.textContent;
				btn.disabled = true;
				btn.textContent = 'Sending…';
				// Open WhatsApp inside the click (pop-up blockers), then point it at the message.
				// The static copy has no request API: everything, VIP Club included, goes to WhatsApp.
				const win = type === 'club' && ! window.UN_STATIC ? null : window.open( '', '_blank' );
				let ref, wa;
				try {
					if ( window.UN_STATIC ) throw new Error( 'static' );
					const res = await fetch( cfg.api + 'request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify( body ) } );
					const j = await res.json();
					if ( ! res.ok ) throw Object.assign( new Error( j.message || 'error' ), { soft: res.status === 400 } );
					ref = j.ref;
					wa = j.wa;
				} catch ( err ) {
					if ( err.soft ) {
						if ( win ) win.close();
						toast( esc( err.message ) );
						btn.disabled = false;
						btn.textContent = label;
						return;
					}
					// No request API (static copy): make a reference here and send it all on WhatsApp.
					ref = 'UN-' + { event: 'G', club: 'C' }[ type ] + String( Date.now() ).slice( -5 );
					const intro = { event: HI + 'I\'d like a quote for a group order', club: HI + 'please add me to the VIP Club' }[ type ];
					const lines = [];
					fd.forEach( ( v, k ) => {
						if ( k !== 'website' && String( v ).trim() ) {
							const el = form.elements[ k ];
							lines.push( k.charAt( 0 ).toUpperCase() + k.slice( 1 ) + ': ' + ( el && el.tagName === 'SELECT' ? el.selectedOptions[ 0 ].text : v ) );
						}
					} );
					wa = waUrl( intro + ' (ref ' + ref + '):\n' + lines.join( '\n' ) );
				}
				btn.disabled = false;
				btn.textContent = label;
				if ( type === 'club' ) {
					if ( win ) win.location = wa;
					toast( '🍔 Welcome to the VIP Club! Offers and new-menu drops come on WhatsApp (ref ' + esc( ref ) + ').' );
					form.reset();
					return;
				}
				if ( win ) win.location = wa;
				else window.open( wa, '_blank' );
				toast( '✓ Group order request <strong>' + esc( ref ) + '</strong> sent. We reply on WhatsApp with a quote.' );
				form.reset();
			} );
		} );
	}

	/* Copy a branch location ------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-un-copy-loc]' );
		if ( ! b ) return;
		e.preventDefault();
		const text = b.dataset.unCopyLoc === 'ngummo' ? 'Uncle Nene\'s, Ngummo kitchen, Mbagathi Road (MRQ2+C6), Nairobi\n' + cfg.maps.ngummo : 'Uncle Nene\'s, Amani Food Court, Berea Road, Garden Estate, Nairobi\n' + cfg.maps.garden;
		try {
			await navigator.clipboard.writeText( text );
			toast( '📍 Location copied. Paste it to your rider, driver or friends.' );
		} catch ( err ) {
			window.prompt( 'Copy our location:', text );
		}
	} );

	/* Open now, and the day's offer in the top bar ------------------------- */
	function nairobiNow() {
		const now = new Date( Date.now() + ( new Date().getTimezoneOffset() + 180 ) * 60000 );
		return { day: now.getDay(), hm: String( now.getHours() ).padStart( 2, '0' ) + ':' + String( now.getMinutes() ).padStart( 2, '0' ) };
	}
	function initClock() {
		const n = nairobiNow();
		const closedDay = ( day ) => ( cfg.closed || [] ).indexOf( day ) > -1;
		const open = ! closedDay( n.day ) && n.hm >= cfg.open && n.hm < cfg.close;
		const h12 = ( hm ) => {
			const [ h, m ] = hm.split( ':' ).map( Number );
			return ( h % 12 || 12 ) + ( m ? ':' + String( m ).padStart( 2, '0' ) : '' ) + ( h < 12 ? ' am' : ' pm' );
		};
		// When do we open next?
		let next = '';
		if ( ! open ) {
			const today = ! closedDay( n.day ) && n.hm < cfg.open;
			let d = n.day;
			let k = 0;
			if ( ! today ) {
				do {
					d = ( d + 1 ) % 7;
					k++;
				} while ( closedDay( d ) );
			}
			next = ( today ? 'today ' : k === 1 ? 'tomorrow ' : [ 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday' ][ d ] + ' ' ) + h12( cfg.open );
		}
		const lastCall = open && n.hm >= '18:00';
		$$( '[data-un-open]' ).forEach( ( el ) => {
			el.classList.toggle( 'is-open', open );
			el.textContent = open ? ( lastCall ? 'Last orders now · kitchen closes ' + h12( cfg.close ) : 'Kitchen open · until ' + h12( cfg.close ) ) : 'Kitchen closed · opens ' + next;
		} );
		$$( '[data-un-promo]' ).forEach( ( el ) => {
			const lunch = open && n.hm >= '11:00' && n.hm < '14:00';
			el.innerHTML = ! open
				? '⏰ Kitchen opens ' + next + ': <a href="/menu/">plan your order</a> and send it when we open'
				: lunch
					? '🔥 Lunch rush: order now and beat the queue on the grill'
					: lastCall
						? '⏳ Last orders: the grill shuts at ' + h12( cfg.close )
						: n.day === 5 || n.day === 6
							? '🍔 Weekend sorted: <strong>Patty Party Pack</strong>, 5 burgers + fries, KSh 5,000, free delivery'
							: '💼 Feeding the office? <strong>Patty Party Pack</strong>: 5 burgers + fries for KSh 5,000';
		} );
	}

	/* Product page: option buttons, live option price, WhatsApp ------------ */
	function initPdp() {
		$$( 'form.variations_form select[name^="attribute_"]' ).forEach( ( sel ) => {
			if ( sel.dataset.unSw ) return;
			sel.dataset.unSw = '1';
			const wrap = document.createElement( 'div' );
			wrap.className = 'un-pills un-sw';
			wrap.setAttribute( 'role', 'radiogroup' );
			const vars = ( () => {
				try {
					return JSON.parse( sel.closest( 'form' ).dataset.product_variations || '[]' );
				} catch ( e ) {
					return [];
				}
			} )();
			wrap.innerHTML = Array.from( sel.options ).filter( ( o ) => o.value ).map( ( o ) => {
				const v = vars.find( ( x ) => Object.values( x.attributes || {} ).indexOf( o.value ) > -1 );
				return '<button type="button" role="radio" data-v="' + esc( o.value ) + '"><span>' + esc( o.text ) + '</span>' + ( v ? '<small>' + fmt( v.display_price ) + '</small>' : '' ) + '</button>';
			} ).join( '' );
			sel.after( wrap );
			sel.classList.add( 'un-sw-select' );
			const paint = () => $$( 'button', wrap ).forEach( ( b ) => {
				b.classList.toggle( 'is-on', b.dataset.v === sel.value );
				b.setAttribute( 'aria-checked', b.dataset.v === sel.value ? 'true' : 'false' );
			} );
			wrap.addEventListener( 'click', ( e ) => {
				const b = e.target.closest( 'button' );
				if ( ! b ) return;
				sel.value = b.dataset.v;
				sel.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				if ( window.jQuery ) window.jQuery( sel ).trigger( 'change' );
				paint();
			} );
			paint();
		} );
		$$( 'form.variations_form .reset_variations' ).forEach( ( a ) => ( a.hidden = true ) );
		$$( '[data-un-pdp-opts]' ).forEach( ( box ) => {
			if ( box.dataset.unInit ) return;
			box.dataset.unInit = '1';
			let out = box.querySelector( '.un-opt-cost' );
			if ( ! out ) {
				out = document.createElement( 'p' );
				out.className = 'un-opt-cost';
				box.appendChild( out );
			}
			const form = box.closest( 'form' );
			const wa = document.querySelector( '[data-un-wa-pdp]' );
			const upd = () => {
				let add = 0;
				$$( 'input[data-un-cost]:checked', box ).forEach( ( i ) => ( add += Number( i.dataset.unCost ) ) );
				out.textContent = add ? 'Your options add ' + fmt( add ) + ' per item.' : '';
				$$( '.un-pills label, .un-checks label', box ).forEach( ( l ) => l.classList.toggle( 'is-on', l.querySelector( 'input' ).checked ) );
				if ( wa && form ) {
					const picked = [];
					$$( 'select[name^="attribute_"]', form ).forEach( ( s ) => s.value && picked.push( s.options[ s.selectedIndex ].text ) );
					$$( 'input[type=checkbox]:checked, [name="un[dip]"]:checked', box ).forEach( ( i ) => picked.push( i.closest( 'label' ).querySelector( 'span' ).textContent ) );
					if ( box.querySelector( '[name="un[double]"][value=yes]:checked' ) ) picked.push( 'Double' );
					const note = box.querySelector( '[name="un[note]"]' );
					if ( note && note.value.trim() ) picked.push( 'Note: ' + note.value.trim() );
					wa.href = waUrl( [ HI + 'I\'d like to order (' + MODES[ getMode() ] + '):', '• 1 × ' + wa.dataset.unWaPdp + ( picked.length ? ' (' + picked.join( ', ' ) + ')' : '' ), ...modeLines(), 'Name: ' ].join( '\n' ) );
				}
			};
			( form || box ).addEventListener( 'change', upd );
			box.addEventListener( 'input', upd );
			upd();
		} );
	}

	// The sticky header slides up by the announcement bar's height, whatever it wraps to.
	function measureAnnounce() {
		const a = document.querySelector( '.un-announce' );
		if ( a ) document.documentElement.style.setProperty( '--un-ann', a.offsetHeight + 'px' );
	}

	// Header menu: underline the page you're on.
	function markNav() {
		const here = location.pathname;
		const home = new URL( cfg.home || '/', location.href ).pathname;
		$$( '.un-nav a.wp-block-navigation-item__content' ).forEach( ( a ) => {
			const path = new URL( a.href, location.href ).pathname;
			if ( path === home ? here === home : here.startsWith( path ) ) a.setAttribute( 'aria-current', 'page' );
		} );
	}

	function init() {
		markNav();
		paintMode();
		initMenu();
		initSlides();
		initRequests();
		initClock();
		measureAnnounce();
		window.addEventListener( 'resize', measureAnnounce );
		window.addEventListener( 'load', measureAnnounce );
		initPdp();
		new MutationObserver( () => initPdp() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
