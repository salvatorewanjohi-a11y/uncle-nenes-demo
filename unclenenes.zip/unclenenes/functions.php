<?php
/**
 * Uncle Nene's Kitchen child theme: Nairobi burger kitchen, ordered like a shop.
 * The menu is WooCommerce products. Loaded-fries style, drink and shake flavour are variations (they can change
 * the price); "make it a double", add-ons, sides and the free dip are options stored on the cart line and priced here.
 * Orders go to delivery or pickup (Ngummo or Garden Estate) at checkout, or straight to WhatsApp.
 */

const UN_WHATSAPP = '254736713761';
const UN_PHONE    = '0736 713 761';
const UN_TEL      = '+254736713761';
const UN_IG       = 'https://www.instagram.com/unclenenes/';
const UN_UBER     = 'https://www.ubereats.com/ke/store/uncle-nenes-kitchen-mbagathi-road/V7_mDgZSXxaonbnjxGavsQ';
const UN_MAPS_NGUMMO = 'https://www.google.com/maps/search/?api=1&query=Uncle+Nene%27s+Mbagathi+Road+Ngummo';
const UN_MAPS_GARDEN = 'https://www.google.com/maps/search/?api=1&query=Uncle+Nene%27s+Kitchen+Garden+Estate';
const UN_FONTS    = 'https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700;12..96,800&family=DM+Sans:wght@400;500;600;700&family=Caveat:wght@600;700&display=swap';

// Opening hours, from their Instagram bio: 10 am – 7 pm, closed on Sundays. (Google lists Garden Estate until 8 pm: PLACEHOLDER.)
const UN_OPEN   = '10:00';
const UN_CLOSE  = '19:00';
const UN_CLOSED_DAYS = [ 0 ]; // Sunday

// Priced options, from their menu board and Uber Eats store.
const UN_DOUBLE = 250; // "Make any burger a double at an extra 250/="
const UN_EXTRAS = [ 'egg' => [ 'Fried egg', 100 ], 'cheese' => [ 'Extra cheese', 100 ], 'bacon' => [ 'Extra bacon', 200 ], 'jalapenos' => [ 'Jalapeños', 50 ], 'toastbun' => [ 'French toast bun', 250 ] ];
const UN_SIDES  = [ 'fries' => [ 'Large fries', 400 ], 'slaw' => [ 'Coleslaw', 200 ], 'sauce' => [ 'Burger sauce dip', 150 ], 'tartar' => [ 'Tartare sauce dip', 150 ] ];
const UN_DIPS   = [ 'ketchup' => 'Ketchup', 'tartar' => 'Tartare sauce', 'special' => 'Special sauce' ];
const UN_FILTERS = [ 'beef' => 'Beef', 'chicken' => 'Chicken', 'fish' => 'Fish', 'cheese' => 'Cheesy', 'vegetarian' => 'Vegetarian' ];

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'un-fonts', UN_FONTS, [], null );
	wp_enqueue_style( 'un', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'un', $uri . '/assets/un.js', [], filemtime( $dir . '/assets/un.js' ), true );
	wp_localize_script( 'un', 'UN', [
		'store'    => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'api'      => esc_url_raw( rest_url( 'un/v1/' ) ),
		'shop'     => esc_url_raw( home_url( '/menu/' ) ),
		'checkout' => esc_url_raw( wc_get_checkout_url() ),
		'home'     => esc_url_raw( home_url( '/' ) ),
		'wa'       => UN_WHATSAPP,
		'phone'    => UN_PHONE,
		'maps'     => [ 'ngummo' => UN_MAPS_NGUMMO, 'garden' => UN_MAPS_GARDEN ],
		'open'     => UN_OPEN,
		'close'    => UN_CLOSE,
		'closed'   => UN_CLOSED_DAYS,
		'menu'     => is_cart() || is_checkout() ? [] : un_menu_data(),
		'opts'     => [ 'double' => UN_DOUBLE, 'extras' => UN_EXTRAS, 'sides' => UN_SIDES, 'dips' => UN_DIPS ],
	] );
} );

add_action( 'enqueue_block_editor_assets', fn() => wp_enqueue_style( 'un-fonts', UN_FONTS, [], null ) );
add_action( 'after_setup_theme', fn() => add_editor_style( 'style.css' ) );

// WooCommerce's symbol for Kenyan shillings is "KSh", the way businesses here write it.
add_filter( 'woocommerce_currency_symbol', fn( $s, $c ) => $c === 'KES' ? 'KSh' : $s, 10, 2 );

function un_wa_link( $text = '' ) {
	return 'https://wa.me/' . UN_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}
function un_money( $amount ) {
	return 'KSh ' . number_format( (float) $amount );
}
function un_lines( $product_id, $key ) {
	return array_values( array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_post_meta( $product_id, '_un_' . $key, true ) ) ) ) );
}
function un_opts( $product_id ) {
	return array_values( array_filter( explode( ',', (string) get_post_meta( $product_id, '_un_opts', true ) ) ) );
}
function un_is_dinein( $product_id ) {
	return get_post_meta( $product_id, '_un_dinein', true ) === 'yes';
}

const UN_WA_ICON = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>';

/* -------------------------------------------------------------------------
 * Menu data (one list for the menu grid, the dish pop-up and the cart)
 * ---------------------------------------------------------------------- */

function un_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

function un_menu_data() {
	static $out = null;
	if ( $out !== null ) {
		return $out;
	}
	$out      = [];
	$products = wc_get_products( [ 'status' => 'publish', 'limit' => -1, 'orderby' => 'menu_order', 'order' => 'ASC' ] );
	foreach ( $products as $p ) {
		$id   = $p->get_id();
		$cats = get_the_terms( $id, 'product_cat' ) ?: [];
		$imgs = [];
		foreach ( array_merge( [ $p->get_image_id() ], $p->get_gallery_image_ids() ) as $aid ) {
			$src = $aid ? wp_get_attachment_image_url( $aid, 'woocommerce_single' ) : '';
			if ( $src ) $imgs[] = $src;
		}
		$choices = [];
		$label   = '';
		if ( $p->is_type( 'variable' ) ) {
			foreach ( $p->get_children() as $vid ) {
				$v = wc_get_product( $vid );
				if ( ! $v || ! $v->is_purchasable() ) continue;
				$a         = $v->get_attributes();
				$choices[] = [ 'id' => $vid, 'label' => (string) reset( $a ), 'price' => (float) $v->get_price() ];
			}
			$attrs = $p->get_attributes();
			$label = $attrs ? wc_attribute_label( reset( $attrs )->get_name(), $p ) : '';
		}
		$clip = get_post_meta( $id, '_un_clip', true );
		$out[ $id ] = [
			'id'        => $id,
			'name'      => $p->get_name(),
			'line'      => get_post_meta( $id, '_un_line', true ),
			'cat'       => $cats ? $cats[0]->slug : '',
			'catName'   => $cats ? html_entity_decode( $cats[0]->name ) : '',
			'price'     => $choices ? min( array_column( $choices, 'price' ) ) : (float) $p->get_price(),
			'choices'   => $choices,
			'choice'    => $label,
			'opts'      => un_opts( $id ),
			'tags'      => wp_get_post_terms( $id, 'product_tag', [ 'fields' => 'slugs' ] ),
			'short'     => wp_strip_all_tags( $p->get_short_description() ),
			'portion'   => get_post_meta( $id, '_un_portion', true ),
			'ingr'      => un_lines( $id, 'ingredients' ),
			'allergens' => un_lines( $id, 'allergens' ),
			'badge'     => get_post_meta( $id, '_un_badge', true ),
			'likes'     => get_post_meta( $id, '_un_likes', true ),
			'clip'      => $clip ? get_stylesheet_directory_uri() . '/assets/clips/' . $clip . '.mp4' : '',
			'reel'      => get_post_meta( $id, '_un_reel', true ),
			'drawn'     => get_post_meta( $id, '_un_drawn', true ) === 'yes',
			'dinein'    => un_is_dinein( $id ),
			'stock'     => $p->is_in_stock(),
			'imgs'      => $imgs,
			'url'       => get_permalink( $id ),
			'featured'  => $p->is_featured(),
			'order'     => $p->get_menu_order(),
		];
	}
	return $out;
}

/* -------------------------------------------------------------------------
 * Menu grid: [un_menu] (filters + every dish) and [un_menu preview="1"]
 * ---------------------------------------------------------------------- */

function un_card( array $d ) {
	$slides = '';
	foreach ( $d['imgs'] ?: [ '' ] as $i => $src ) {
		$slides .= '<img src="' . esc_url( $src ) . '" alt="' . ( $i ? '' : esc_attr( $d['name'] ) ) . '" loading="lazy" width="720" height="720">';
	}
	$dots  = count( $d['imgs'] ) > 1 ? '<span class="un-card__dots">' . str_repeat( '<i></i>', count( $d['imgs'] ) ) . '</span>' : '';
	$metas = '';
	if ( in_array( 'double', $d['opts'], true ) ) $metas .= '<span class="un-meta un-meta--hot">Double it +' . UN_DOUBLE . '</span>';
	if ( $d['portion'] ) $metas .= '<span class="un-meta">' . esc_html( $d['portion'] ) . '</span>';
	if ( $d['dinein'] ) $metas .= '<span class="un-meta un-meta--dinein">Garden Estate only</span>';
	if ( in_array( 'vegetarian', $d['tags'], true ) ) $metas .= '<abbr class="un-diet" title="Vegetarian">V</abbr>';
	$simple = ! $d['choices'] && ! $d['opts'];
	$wa     = 'Hi Uncle Nene\'s, I\'d like to order: ' . $d['name'] . ' (' . un_money( $d['price'] ) . ').';
	return sprintf(
		'<article class="un-card%22$s" data-un-card data-id="%1$d" data-cat="%2$s" data-tags="%3$s" data-price="%4$d" data-order="%5$d" data-name="%6$s"%21$s>
			<div class="un-card__media"><a class="un-card__slides" href="%7$s" data-un-dish="%1$d" aria-label="%8$s">%9$s</a>%10$s%11$s</div>
			<div class="un-card__body">
				<p class="un-card__line">%12$s</p>
				<h3 class="un-card__title"><a href="%7$s" data-un-dish="%1$d">%8$s</a></h3>
				<p class="un-card__short">%13$s</p>
				<div class="un-card__metas">%14$s</div>
				<div class="un-card__foot">
					<p class="un-card__price">%15$s</p>
					<div class="un-card__actions">
						<a class="un-icon-btn un-icon-btn--wa" href="%16$s" target="_blank" rel="noopener" aria-label="Order %8$s on WhatsApp" data-un-wa-item="%1$d">%17$s</a>
						%18$s
						<button type="button" class="un-btn-add" data-un-quick="%1$d"%19$s aria-label="Add %8$s to your order"%20$s>%23$s</button>
					</div>
				</div>
			</div>
		</article>',
		$d['id'],
		esc_attr( $d['cat'] ),
		esc_attr( implode( ' ', $d['tags'] ) ),
		(int) $d['price'],
		$d['order'],
		esc_attr( strtolower( $d['name'] . ' ' . $d['line'] . ' ' . implode( ' ', $d['ingr'] ) . ' ' . implode( ' ', array_column( $d['choices'], 'label' ) ) . ' ' . $d['catName'] ) ),
		esc_url( $d['url'] ),
		esc_attr( $d['name'] ),
		$slides,
		$dots,
		$d['badge'] ? '<span class="un-card__badge">' . esc_html( $d['badge'] ) . '</span>' : '',
		esc_html( $d['line'] ),
		esc_html( $d['short'] ),
		$metas,
		( $d['choices'] && count( array_unique( array_column( $d['choices'], 'price' ) ) ) > 1 ? '<small>from</small> ' : '' ) . esc_html( un_money( $d['price'] ) ),
		esc_url( un_wa_link( $wa ) ),
		UN_WA_ICON,
		$simple ? '' : '<button type="button" class="un-btn-line" data-un-dish="' . $d['id'] . '">' . ( $d['choices'] && ! $d['opts'] ? 'Choose' : 'Customise' ) . '</button>',
		$simple ? '' : ' data-un-has-opts',
		$d['stock'] ? '' : ' disabled',
		$d['featured'] ? ' data-featured' : '',
		$d['dinein'] ? ' un-card--dinein' : '',
		$d['stock'] ? 'Add' : 'Sold out'
	);
}

add_shortcode( 'un_menu', function ( $atts ) {
	$atts = shortcode_atts( [ 'cat' => '', 'preview' => '' ], $atts );
	$menu = un_menu_data();
	$current = $atts['cat'];
	$q       = get_queried_object();
	if ( ! $current && $q instanceof WP_Term && $q->taxonomy === 'product_cat' ) {
		$current = $q->slug;
	}
	$cats  = un_categories();
	$chips = '<button type="button" class="un-chip' . ( $current ? '' : ' is-on' ) . '" data-un-cat="">All</button>';
	foreach ( $cats as $t ) {
		$chips .= '<button type="button" class="un-chip' . ( $current === $t->slug ? ' is-on' : '' ) . '" data-un-cat="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</button>';
	}
	$filters = '';
	foreach ( UN_FILTERS as $slug => $label ) {
		$filters .= '<button type="button" class="un-chip un-chip--sm" data-un-diet="' . esc_attr( $slug ) . '" aria-pressed="false">' . esc_html( $label ) . '</button>';
	}
	$filters .= '<button type="button" class="un-chip un-chip--sm" data-un-diet="no-bacon" aria-pressed="false">No bacon</button>';

	ob_start();
	?>
	<div class="un-menu<?php echo $atts['preview'] ? ' is-preview' : ''; ?>" data-un-menu<?php echo $current ? ' data-start-cat="' . esc_attr( $current ) . '"' : ''; ?><?php echo $atts['preview'] ? ' data-un-preview' : ''; ?>>
		<div class="un-hub" data-un-hub>
			<div class="un-hub__row un-hub__row--top">
				<label class="un-search"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="m21 21-4.3-4.3M10.5 18a7.5 7.5 0 1 1 0-15 7.5 7.5 0 0 1 0 15Z"/></svg><span class="screen-reader-text">Search the menu</span><input type="search" placeholder="Search beast, bacon, loaded fries…" data-un-q autocomplete="off"></label>
				<div class="un-seg" role="group" aria-label="How you want it" data-un-mode-group>
					<button type="button" data-un-mode="delivery" aria-pressed="true">🛵 Delivery</button>
					<button type="button" data-un-mode="pickup" aria-pressed="false">🛍 Pickup</button>
					<button type="button" data-un-mode="dinein" aria-pressed="false">🍽 Dine-in</button>
				</div>
			</div>
			<div class="un-hub__row un-chips" role="group" aria-label="Menu section"><?php echo $chips; // phpcs:ignore ?></div>
			<details class="un-hub__more" data-un-more>
				<summary><span>What's in it &amp; budget</span><em data-un-active></em></summary>
				<div class="un-hub__filters">
					<div class="un-filter"><p>What's in it</p><div class="un-chips"><?php echo $filters; // phpcs:ignore ?></div></div>
					<div class="un-filter un-filter--price"><p>Budget <strong data-un-price-label>Any price</strong></p>
						<input type="range" min="200" max="2000" step="100" value="2000" data-un-price aria-label="Highest price">
						<div class="un-range-ends"><span>KSh 200</span><span>KSh 2,000+</span></div>
					</div>
				</div>
			</details>
			<div class="un-hub__status"><p data-un-count aria-live="polite"></p><div><select data-un-sort aria-label="Sort the menu"><option value="">Menu order</option><option value="popular">Most loved first</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select><button type="button" class="un-link-btn" data-un-clear hidden>Clear filters</button></div></div>
			<p class="un-mode-note" data-un-mode-note></p>
		</div>
		<div class="un-menu__secs">
		<?php foreach ( $cats as $t ) : ?>
			<section class="un-menu__sec" id="<?php echo esc_attr( $t->slug ); ?>" data-un-sec="<?php echo esc_attr( $t->slug ); ?>">
				<div class="un-menu__head"><h2><?php echo esc_html( $t->name ); ?></h2><p><?php echo esc_html( $t->description ); ?></p></div>
				<div class="un-grid">
					<?php
					foreach ( $menu as $d ) {
						if ( $d['cat'] === $t->slug ) echo un_card( $d ); // phpcs:ignore
					}
					?>
				</div>
			</section>
		<?php endforeach; ?>
		</div>
		<?php if ( $atts['preview'] ) : ?>
			<div class="un-preview-more" data-un-preview-more><p>Those are the 8 everyone orders. Search or filter above to see everything that matches, or open the whole menu: <?php echo count( $menu ); ?> burgers, boxes, sides &amp; drinks.</p><a class="wp-element-button" href="<?php echo esc_url( home_url( '/menu/' ) ); ?>">See the full menu</a></div>
		<?php endif; ?>
		<div class="un-empty" data-un-empty hidden><p>Nothing matches all of that. <button type="button" class="un-link-btn" data-un-clear>Clear the filters</button> or <a href="<?php echo esc_url( un_wa_link( 'Hi Uncle Nene\'s, can you make me something special?' ) ); ?>" target="_blank" rel="noopener">ask the kitchen on WhatsApp</a>.</p></div>
	</div>
	<?php
	return ob_get_clean();
} );

// Hero craving finder: a few taps, then the menu opens filtered.
add_shortcode( 'un_finder', function () {
	$cats = '';
	foreach ( un_categories() as $t ) {
		$cats .= '<option value="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</option>';
	}
	return '<form class="un-finder" action="' . esc_url( home_url( '/menu/' ) ) . '" method="get" data-un-finder>
		<p class="un-finder__title">What are you craving?</p>
		<div class="un-finder__grid">
			<label>Craving<select name="cat"><option value="">Everything</option>' . $cats . '</select></label>
			<label>Protein<select name="diet"><option value="">Any</option><option value="beef">Beef</option><option value="chicken">Chicken</option><option value="fish">Fish</option><option value="vegetarian">Vegetarian</option><option value="no-bacon">No bacon</option></select></label>
			<label>Budget<select name="max"><option value="">Any</option><option value="1100">Up to KSh 1,100</option><option value="1200">Up to KSh 1,200</option><option value="1500">Up to KSh 1,500</option><option value="2000">Up to KSh 2,000</option></select></label>
		</div>
		<div class="un-seg un-seg--light" role="group" aria-label="How you want it" data-un-mode-group>
			<button type="button" data-un-mode="delivery" aria-pressed="true">Delivery</button><button type="button" data-un-mode="pickup" aria-pressed="false">Pickup</button><button type="button" data-un-mode="dinein" aria-pressed="false">Dine-in</button>
		</div>
		<button type="submit" class="wp-element-button un-finder__go">Show me the food</button>
	</form>';
} );

/* -------------------------------------------------------------------------
 * Options on the cart line: double, add-ons, sides, dip, note
 * ---------------------------------------------------------------------- */

/** Cleans submitted options against what the dish offers. */
function un_clean_options( $raw, $product_id ) {
	$raw  = is_array( $raw ) ? $raw : [];
	$opts = un_opts( $product_id );
	$out  = [];
	if ( in_array( 'double', $opts, true ) && ! empty( $raw['double'] ) && $raw['double'] !== 'no' ) {
		$out['double'] = 1;
	}
	foreach ( [ 'extras' => UN_EXTRAS, 'sides' => UN_SIDES ] as $key => $list ) {
		if ( in_array( $key, $opts, true ) ) {
			$picked = array_values( array_intersect( (array) ( $raw[ $key ] ?? [] ), array_keys( $list ) ) );
			if ( $picked ) $out[ $key ] = $picked;
		}
	}
	if ( in_array( 'dip', $opts, true ) ) {
		$dip        = (string) ( $raw['dip'] ?? '' );
		$out['dip'] = isset( UN_DIPS[ $dip ] ) ? $dip : array_key_first( UN_DIPS );
	}
	$note = trim( sanitize_text_field( (string) ( $raw['note'] ?? '' ) ) );
	if ( $note !== '' ) $out['note'] = mb_substr( $note, 0, 160 );
	return $out;
}

/** What the options add to one item's price. */
function un_options_cost( array $o ) {
	$add = empty( $o['double'] ) ? 0 : UN_DOUBLE;
	foreach ( $o['extras'] ?? [] as $e ) {
		$add += UN_EXTRAS[ $e ][1] ?? 0;
	}
	foreach ( $o['sides'] ?? [] as $s ) {
		$add += UN_SIDES[ $s ][1] ?? 0;
	}
	return $add;
}

/** The options as label => value lines, for the cart, the order and WhatsApp. */
function un_options_lines( array $o ) {
	$out = [];
	if ( ! empty( $o['double'] ) ) $out['Double'] = 'Extra patty +' . un_money( UN_DOUBLE );
	if ( ! empty( $o['extras'] ) ) $out['Add-ons'] = implode( ', ', array_map( fn( $e ) => UN_EXTRAS[ $e ][0] . ' +' . un_money( UN_EXTRAS[ $e ][1] ), $o['extras'] ) );
	if ( ! empty( $o['sides'] ) ) $out['Sides'] = implode( ', ', array_map( fn( $s ) => UN_SIDES[ $s ][0] . ' +' . un_money( UN_SIDES[ $s ][1] ), $o['sides'] ) );
	if ( ! empty( $o['dip'] ) ) $out['Dip'] = UN_DIPS[ $o['dip'] ];
	if ( ! empty( $o['note'] ) ) $out['Note'] = $o['note'];
	return $out;
}

// Product page form (classic POST) and the Store API (our dish pop-up sends "un": {...}).
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	if ( isset( $data['un'] ) ) {
		return $data;
	}
	if ( isset( $_POST['un'] ) ) { // phpcs:ignore
		$data['un'] = un_clean_options( wp_unslash( $_POST['un'] ), $product_id ); // phpcs:ignore
	} elseif ( un_opts( $product_id ) ) {
		$data['un'] = un_clean_options( [], $product_id );
	}
	return $data;
}, 10, 2 );
add_filter( 'woocommerce_store_api_add_to_cart_data', function ( $data, $request ) {
	$product   = wc_get_product( $data['id'] );
	$parent_id = $product && $product->get_parent_id() ? $product->get_parent_id() : (int) $data['id'];
	$data['cart_item_data']       = $data['cart_item_data'] ?? [];
	$data['cart_item_data']['un'] = un_clean_options( $request['un'] ?? [], $parent_id );
	return $data;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	foreach ( $cart->get_cart() as $item ) {
		if ( empty( $item['un'] ) ) continue;
		$base = wc_get_product( $item['variation_id'] ?: $item['product_id'] );
		if ( $base ) $item['data']->set_price( (float) $base->get_price() + un_options_cost( $item['un'] ) );
	}
}, 20 );

add_filter( 'woocommerce_get_item_data', function ( $rows, $item ) {
	foreach ( un_options_lines( $item['un'] ?? [] ) as $k => $v ) {
		$rows[] = [ 'key' => $k, 'value' => $v ];
	}
	if ( un_is_dinein( $item['product_id'] ) ) {
		$rows[] = [ 'key' => 'Served at', 'value' => 'Garden Estate (dine-in or Garden Estate pickup)' ];
	}
	return $rows;
}, 10, 2 );
add_action( 'woocommerce_checkout_create_order_line_item', function ( $line, $key, $values ) {
	foreach ( un_options_lines( $values['un'] ?? [] ) as $k => $v ) {
		$line->add_meta_data( $k, $v );
	}
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Dish page
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_product_single_add_to_cart_text', fn() => 'Add to my order' );
add_filter( 'woocommerce_product_add_to_cart_text', fn( $t, $p ) => $p && $p->is_in_stock() ? 'Add to order' : $t, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( ! $product->is_in_stock() ) return 'Sold out today';
	$id = $product->get_parent_id() ?: $product->get_id();
	return un_is_dinein( $id ) ? 'Made at Garden Estate · dine-in or Garden Estate pickup' : 'Made to order · delivery or pickup';
}, 10, 2 );
add_filter( 'woocommerce_variable_price_html', function ( $html, $product ) {
	$min = $product->get_variation_price( 'min', true );
	$max = $product->get_variation_price( 'max', true );
	return $min === $max ? wc_price( $min ) : '<span class="un-from">from</span> ' . wc_price( $min );
}, 10, 2 );

add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id    = $product->get_id();
	$badge = get_post_meta( $id, '_un_badge', true );
	$likes = get_post_meta( $id, '_un_likes', true );
	$port  = get_post_meta( $id, '_un_portion', true );
	echo '<p class="un-pdp-line">' . esc_html( get_post_meta( $id, '_un_line', true ) ) . '</p>';
	echo '<div class="un-tags">' . ( $badge ? '<span class="un-tag">' . esc_html( $badge ) . '</span>' : '' ) . ( $likes ? '<span class="un-tag un-tag--line">' . esc_html( $likes ) . '</span>' : '' ) . ( $port ? '<span class="un-tag un-tag--line">' . esc_html( $port ) . '</span>' : '' ) . '</div>';
	if ( un_is_dinein( $id ) ) {
		echo '<p class="un-alert">Our shakes, lemonades and hot drinks are made at Amani Food Court, Garden Estate: for dine-in or Garden Estate pickup, not delivery.</p>';
	}
	if ( get_post_meta( $id, '_un_drawn', true ) === 'yes' ) {
		echo '<p class="un-note">The picture is a drawing, not a photo of this item.</p>';
	}
} );

// Double, add-ons, sides and dip inside the add-to-cart form (posted as un[...]).
add_action( 'woocommerce_before_add_to_cart_button', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$opts = un_opts( $product->get_id() );
	if ( ! $opts ) return;
	echo '<div class="un-pdp-opts" data-un-pdp-opts>';
	if ( in_array( 'double', $opts, true ) ) {
		echo '<fieldset class="un-opt"><legend>Size</legend><div class="un-pills"><label><input type="radio" name="un[double]" value="no" checked><span>Single</span></label><label><input type="radio" name="un[double]" value="yes" data-un-cost="' . UN_DOUBLE . '"><span>Make it a double <b>+' . esc_html( un_money( UN_DOUBLE ) ) . '</b></span></label></div></fieldset>';
	}
	if ( in_array( 'dip', $opts, true ) ) {
		echo '<fieldset class="un-opt"><legend>Your dip <em>included</em></legend><div class="un-pills">';
		foreach ( UN_DIPS as $k => $label ) {
			echo '<label><input type="radio" name="un[dip]" value="' . esc_attr( $k ) . '"' . checked( $k, array_key_first( UN_DIPS ), false ) . '><span>' . esc_html( $label ) . '</span></label>';
		}
		echo '</div></fieldset>';
	}
	foreach ( [ 'extras' => [ 'Add-ons', UN_EXTRAS ], 'sides' => [ 'Add a side', UN_SIDES ] ] as $key => [ $legend, $list ] ) {
		if ( ! in_array( $key, $opts, true ) ) continue;
		echo '<fieldset class="un-opt"><legend>' . esc_html( $legend ) . '</legend><div class="un-checks">';
		foreach ( $list as $k => [ $label, $price ] ) {
			echo '<label><input type="checkbox" name="un[' . $key . '][]" value="' . esc_attr( $k ) . '" data-un-cost="' . (int) $price . '"><span>' . esc_html( $label ) . '</span><b>+' . esc_html( un_money( $price ) ) . '</b></label>'; // phpcs:ignore
		}
		echo '</div></fieldset>';
	}
	echo '<label class="un-opt un-opt--note">Requests<input type="text" name="un[note]" maxlength="160" placeholder="e.g. no onions, sauce on the side, Fanta"></label>';
	echo '</div>';
} );

add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) return;
	$id  = $product->get_id();
	$msg = 'Hi Uncle Nene\'s, I\'d like to order: ' . $product->get_name() . '. ' . $product->get_permalink();
	echo '<a class="un-wa-order" data-un-wa-pdp="' . esc_attr( $product->get_name() ) . '" href="' . esc_url( un_wa_link( $msg ) ) . '" target="_blank" rel="noopener">' . UN_WA_ICON . 'Instant WhatsApp order · ' . esc_html( UN_PHONE ) . '</a>';
	$clip = get_post_meta( $id, '_un_clip', true );
	if ( $clip ) {
		echo '<figure class="un-pdp-clip"><video src="' . esc_url( get_stylesheet_directory_uri() . '/assets/clips/' . $clip . '.mp4' ) . '" muted loop playsinline autoplay preload="metadata"></video><figcaption>' . esc_html( [ 'grill' => 'Seared on the grill, built layer by layer, to order.', 'fries' => 'Loaded the moment you order.', 'shake' => 'Blended thick at Garden Estate.' ][ $clip ] ?? '' ) . '</figcaption></figure>';
	}
	$reel = get_post_meta( $id, '_un_reel', true );
	if ( $reel ) {
		echo '<a class="un-reel" href="' . esc_url( $reel ) . '" target="_blank" rel="noopener"><span aria-hidden="true">▶</span>Watch it on our Instagram</a>';
	}
	echo '<div class="un-promise"><div><span aria-hidden="true">🔥</span><p><strong>Made when you order</strong>Seared, fried and boxed fresh. Nothing sits under a lamp.</p></div><div><span aria-hidden="true">🛵</span><p><strong>Delivery or pickup</strong>Our riders from Ngummo and Garden Estate, or collect from either kitchen.</p></div><div><span aria-hidden="true">✓</span><p><strong>Pay on delivery</strong>M-Pesa or cash when it reaches you.</p></div></div>';
} );

add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) return $tabs;
	$id = $product->get_id();
	if ( isset( $tabs['description'] ) ) $tabs['description']['title'] = 'About this';
	$ingr = un_lines( $id, 'ingredients' );
	$alg  = un_lines( $id, 'allergens' );
	$tabs['un_sheet'] = [
		'title'    => 'What\'s in it',
		'priority' => 5,
		'callback' => function () use ( $ingr, $alg ) {
			echo '<div class="un-sheet"><div><h3>What\'s in it</h3><ul class="un-checks-list">';
			foreach ( $ingr as $s ) echo '<li>' . esc_html( $s ) . '</li>';
			echo '</ul></div><div><h3>Allergens</h3>' . ( $alg ? '<ul class="un-alg">' . implode( '', array_map( fn( $a ) => '<li>' . esc_html( $a ) . '</li>', $alg ) ) . '</ul>' : '<p>None of the common allergens.</p>' );
			echo '<p class="un-small">Our kitchen handles wheat, egg, milk, sesame and fish. Tell us about any allergy before you order.</p></div></div>';
		},
	];
	unset( $tabs['additional_information'] );
	return $tabs;
}, 20 );

add_action( 'init', fn() => remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 ) );

/* -------------------------------------------------------------------------
 * Requests: office & group orders, VIP Club
 * ---------------------------------------------------------------------- */

add_action( 'init', function () {
	register_post_type( 'un_request', [
		'label'           => 'Group orders & VIP Club',
		'labels'          => [ 'name' => 'Group orders & VIP Club', 'singular_name' => 'Request', 'edit_item' => 'Request', 'all_items' => 'Group orders & VIP Club' ],
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'woocommerce',
		'supports'        => [ 'title', 'editor' ],
		'capability_type' => 'post',
		'capabilities'    => [ 'create_posts' => 'do_not_allow' ],
		'map_meta_cap'    => true,
	] );
} );

// type => [ title, reference letter, WhatsApp opening line ].
const UN_REQUEST_TYPES = [
	'event' => [ 'Office / group order', 'G', 'Hi Uncle Nene\'s, I\'d like a quote for a group order' ],
	'club'  => [ 'VIP Club sign-up', 'C', 'Hi Uncle Nene\'s, please add me to the VIP Club' ],
];
// What each form sends: field => label. Required fields end in "*".
const UN_REQUEST_FIELDS = [
	'event' => [ 'kind*' => 'Occasion', 'date*' => 'Date', 'time' => 'Time', 'guests*' => 'People', 'where' => 'Where', 'budget' => 'Budget per head', 'name*' => 'Name', 'phone*' => 'Phone', 'notes' => 'Notes' ],
	'club'  => [ 'name*' => 'Name', 'contact*' => 'WhatsApp or email' ],
];

add_filter( 'manage_un_request_posts_columns', fn( $c ) => [ 'cb' => $c['cb'], 'title' => 'Request', 'un_type' => 'Type', 'un_phone' => 'Contact', 'date' => 'Received' ] );
add_action( 'manage_un_request_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'un_type' ) echo esc_html( UN_REQUEST_TYPES[ get_post_meta( $id, '_un_type', true ) ][0] ?? '' );
	if ( $col === 'un_phone' ) {
		$c      = get_post_meta( $id, '_un_contact', true );
		$digits = preg_replace( '/\D/', '', (string) $c );
		echo strlen( $digits ) >= 9 && ! str_contains( $c, '@' ) ? '<a href="https://wa.me/' . esc_attr( str_starts_with( $digits, '0' ) ? '254' . substr( $digits, 1 ) : $digits ) . '" target="_blank" rel="noopener">' . esc_html( $c ) . '</a>' : esc_html( $c );
	}
}, 10, 2 );

add_action( 'rest_api_init', function () {
	register_rest_route( 'un/v1', '/request', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$type = sanitize_key( $req['type'] );
			if ( ! isset( UN_REQUEST_FIELDS[ $type ] ) ) {
				return new WP_Error( 'un_type', 'Unknown request.', [ 'status' => 400 ] );
			}
			if ( ! empty( $req['website'] ) ) { // a field people can't see: only bots fill it in
				return new WP_Error( 'un_spam', 'Request not sent.', [ 'status' => 400 ] );
			}
			$ip   = 'un_rl_' . md5( $_SERVER['REMOTE_ADDR'] ?? '' );
			$hits = (int) get_transient( $ip );
			if ( $hits >= 8 ) {
				return new WP_Error( 'un_slow', 'Too many requests. Please call or WhatsApp us on ' . UN_PHONE . '.', [ 'status' => 429 ] );
			}
			set_transient( $ip, $hits + 1, 10 * MINUTE_IN_SECONDS );

			$data = [];
			$rows = [];
			foreach ( UN_REQUEST_FIELDS[ $type ] as $key => $label ) {
				$field = rtrim( $key, '*' );
				$value = trim( sanitize_text_field( (string) $req[ $field ] ) );
				if ( $field === 'date' && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
					$value = wp_date( 'D j M Y', strtotime( $value . ' 12:00' ) );
				}
				if ( $field === 'time' && preg_match( '/^\d{2}:\d{2}$/', $value ) ) {
					$value = gmdate( 'g:i a', strtotime( '2000-01-01 ' . $value . ' UTC' ) );
				}
				if ( $value === '' && str_ends_with( $key, '*' ) ) {
					return new WP_Error( 'un_missing', 'Please fill in: ' . $label . '.', [ 'status' => 400 ] );
				}
				$data[ $field ] = mb_substr( $value, 0, 600 );
				if ( $data[ $field ] !== '' ) $rows[] = $label . ': ' . $data[ $field ];
			}
			[ $title, $letter, $intro ] = UN_REQUEST_TYPES[ $type ];
			$id = wp_insert_post( [ 'post_type' => 'un_request', 'post_status' => 'publish', 'post_title' => $title . ' – ' . $data['name'], 'post_content' => implode( "\n", $rows ) ] );
			if ( ! $id || is_wp_error( $id ) ) {
				return new WP_Error( 'un_save', 'Could not save your request. Please WhatsApp us on ' . UN_PHONE . '.', [ 'status' => 500 ] );
			}
			$ref = 'UN-' . $letter . $id;
			update_post_meta( $id, '_un_type', $type );
			update_post_meta( $id, '_un_contact', $data['phone'] ?? $data['contact'] ?? '' );
			update_post_meta( $id, '_un_ref', $ref );
			wp_update_post( [ 'ID' => $id, 'post_title' => $title . ' – ' . $data['name'] . ' (' . $ref . ')' ] );
			wp_mail( get_option( 'admin_email' ), 'New ' . strtolower( $title ) . ' ' . $ref, implode( "\n", $rows ) );
			$text = $intro . " (ref $ref):\n" . implode( "\n", $rows );
			return [ 'ref' => $ref, 'wa' => un_wa_link( $text ) ];
		},
	] );
} );

add_shortcode( 'un_event_form', function () {
	return '<form class="un-form" data-un-request="event" novalidate>
		<div class="un-form__grid">
			<label>Occasion<select name="kind" required><option>Office lunch</option><option>Team meeting or training</option><option>Birthday or party</option><option>Watch party</option><option>Family get-together</option><option>Something else</option></select></label>
			<label>Date<input type="date" name="date" required min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '"></label>
			<label>Time<input type="time" name="time" min="10:30" max="18:30" value="13:00"></label>
			<label>How many people<input type="number" name="guests" min="5" max="500" value="15" inputmode="numeric" required></label>
			<label>Where<select name="where"><option>Delivered to our office</option><option>Delivered to a home or venue</option><option>We\'ll pick up at Ngummo</option><option>We\'ll pick up at Garden Estate</option><option>Group dine-in at Garden Estate</option></select></label>
			<label>Budget per head<select name="budget"><option>Up to KSh 1,200</option><option selected>KSh 1,200 – 1,500</option><option>KSh 1,500 – 2,000</option><option>KSh 2,000+</option></select></label>
			<label>Your name<input type="text" name="name" autocomplete="name" required></label>
			<label>Phone / WhatsApp<input type="tel" name="phone" autocomplete="tel" inputmode="tel" required placeholder="07…"></label>
		</div>
		<label class="un-form__full">Tell us more<input type="text" name="notes" maxlength="400" placeholder="Beef / chicken split, office address, invoice needed…"></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="un-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button un-form__go">Get my quote</button>
		<p class="un-small">We reply on WhatsApp with a menu, a price and a delivery time. For up to 5 people, the <a href="/menu/#family">Patty Party Pack</a> is quicker.</p>
	</form>';
} );

add_shortcode( 'un_club_form', function () {
	return '<form class="un-club" data-un-request="club" novalidate>
		<label><span class="screen-reader-text">Your name</span><input type="text" name="name" placeholder="Your name" autocomplete="name" required></label>
		<label><span class="screen-reader-text">WhatsApp number or email</span><input type="text" name="contact" placeholder="WhatsApp number or email" required></label>
		<input type="text" name="website" tabindex="-1" autocomplete="off" class="un-hp" aria-hidden="true">
		<button type="submit" class="wp-element-button">Join the club</button>
	</form>';
} );

// Reviews: real Google reviews of both branches (Ngummo 4.5 from 77, Garden Estate 4.5 from 28, 13 Oct 2026).
add_shortcode( 'un_reviews', function () {
	$reviews = [
		[ 'Their burgers are 👌🏽 absolutely amazing. Loaded fries an absolute wow! Authentic food that completely takes away that fast-food/take-out template style food.', 'Joanne Rotich Korir', 'Local Guide · Google review, Ngummo' ],
		[ 'Best, juiciest burgers in Nairobi… like I\'m not even joking. Try it out.', 'Imani Bosire', 'Google review, Ngummo' ],
		[ 'Their meals are sooooo hugeee and packed with so much flavour. They also have a bit of games and colouring you could ask for. I would definitely come back!', 'Nasike Kisiangani', 'Google review, Garden Estate' ],
		[ 'Ordered a burger, it was delivered on time and well packaged. The sweetest, delicious huge burger and fries I have ever tasted.', 'Nelly', 'Google review' ],
		[ 'Best burger ever… It\'s so hard to find a good burger joint. Now I have one. Heaven has a name and it\'s Uncle Nene\'s.', 'Wilson Mukuha', 'Google review' ],
		[ 'This place is worth the hype. Great food and even greater service.', 'Catherine Mugure', 'Google review, Garden Estate' ],
	];
	$h = '<div class="un-reviews"><div class="un-reviews__list">';
	foreach ( $reviews as [ $text, $who, $where ] ) {
		$h .= '<figure class="un-review"><span class="un-stars" aria-label="5 stars">★★★★★</span><blockquote>' . esc_html( $text ) . '</blockquote><figcaption><strong>' . esc_html( $who ) . '</strong><span>' . esc_html( $where ) . '</span></figcaption></figure>';
	}
	$h .= '</div><div class="un-reviews__side"><div class="un-scores">';
	$h .= '<a class="un-score" href="' . esc_url( UN_MAPS_NGUMMO ) . '" target="_blank" rel="noopener"><strong>4.5<span>★</span></strong>Ngummo · 77 Google reviews</a>';
	$h .= '<a class="un-score" href="' . esc_url( UN_MAPS_GARDEN ) . '" target="_blank" rel="noopener"><strong>4.5<span>★</span></strong>Garden Estate · 28 Google reviews</a>';
	$h .= '<a class="un-score" href="' . esc_url( UN_UBER ) . '" target="_blank" rel="noopener"><strong>4.4<span>★</span></strong>Uber Eats · 41 ratings</a>';
	$h .= '<a class="un-score" href="' . esc_url( UN_IG ) . '" target="_blank" rel="noopener"><strong>39.1k</strong>followers on Instagram</a>';
	$h .= '</div><div class="un-score un-score--dish"><p>Most liked on Uber Eats</p><ul><li><span>Beef Bacon Cheese Burger</span><b>#1</b></li><li><span>Beast Burger</span><b>#2</b></li><li><span>Beef Cheese Burger</span><b>#3</b></li></ul></div></div>';
	return $h . '</div>';
} );

/* -------------------------------------------------------------------------
 * Dialogs, floating WhatsApp
 * ---------------------------------------------------------------------- */

add_action( 'wp_footer', function () {
	echo '<dialog id="un-dish" class="un-dialog un-dish" aria-label="Dish details"><form method="dialog"><button class="un-dialog__close" aria-label="Close">×</button></form><div data-un-dish-body></div></dialog>';
	echo '<a class="un-wa-float" href="' . esc_url( un_wa_link( 'Hi Uncle Nene\'s, I\'d like to order:' ) ) . '" target="_blank" rel="noopener" aria-label="Order on WhatsApp">' . UN_WA_ICON . '</a>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, confirmation
 * ---------------------------------------------------------------------- */

function un_cart_note_html() {
	return '<div class="un-cart-note"><strong>Next:</strong> delivery by our riders from KSh 200 (free with the Patty Party Pack), or free pickup at Ngummo or Garden Estate. Pay on delivery by M-Pesa or cash.</div>';
}
function un_wa_cart_html() {
	return '<button type="button" class="un-wa-cart" data-un-wa-cart>' . UN_WA_ICON . 'Order this on WhatsApp instead</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => un_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . un_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', fn( $c ) => preg_replace( '#(<div[^>]*wp-block-woocommerce-mini-cart-items-block)#', un_cart_note_html() . '$1', $c, 1 ) );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="un-wa-cart-wrap">' . un_wa_cart_html() . '</div>' );

add_filter( 'render_block_data', function ( $block ) {
	$labels = [
		'woocommerce/checkout-actions-block'          => [ 'placeOrderButtonLabel', 'Place my order' ],
		'woocommerce/proceed-to-checkout-block'       => [ 'buttonLabel', 'Checkout: delivery or pickup' ],
		'woocommerce/mini-cart-title-label-block'     => [ 'label', 'Your order' ],
		'woocommerce/mini-cart-checkout-button-block' => [ 'checkoutButtonLabel', 'Checkout' ],
		'woocommerce/mini-cart-cart-button-block'     => [ 'cartButtonLabel', 'View order' ],
	];
	if ( isset( $labels[ $block['blockName'] ] ) ) {
		[ $attr, $text ]          = $labels[ $block['blockName'] ];
		$block['attrs'][ $attr ] = $text;
	}
	$steps = [
		'woocommerce/checkout-contact-information-block'    => [ 'Your contact', 'Your order confirmation goes here.' ],
		'woocommerce/checkout-shipping-method-block'        => [ 'Delivery or pickup?', '' ],
		'woocommerce/checkout-pickup-options-block'         => [ 'Which kitchen?', 'Ngummo is a pickup window. Garden Estate has seating, and makes the shakes, lemonades and hot drinks.' ],
		'woocommerce/checkout-billing-address-block'        => [ 'Where should the rider come?', 'Building or estate, and a landmark the rider can find.' ],
		'woocommerce/checkout-shipping-address-block'       => [ 'Where should the rider come?', 'Building or estate, and a landmark the rider can find.' ],
		'woocommerce/checkout-additional-information-block' => [ 'When?', 'As soon as possible, or pick a time.' ],
		'woocommerce/checkout-payment-block'                => [ 'How you\'ll pay', 'Nothing is charged online.' ],
	];
	if ( isset( $steps[ $block['blockName'] ] ) ) {
		[ $block['attrs']['title'], $block['attrs']['description'] ] = $steps[ $block['blockName'] ];
	}
	if ( $block['blockName'] === 'woocommerce/checkout-shipping-method-block' ) {
		$block['attrs']['shippingText']    = 'Delivery';
		$block['attrs']['localPickupText'] = 'Pickup';
	}
	if ( $block['blockName'] === 'woocommerce/checkout-shipping-methods-block' ) {
		$block['attrs']['title']       = 'Delivery distance';
		$block['attrs']['description'] = 'From whichever of our kitchens is nearer you: Ngummo (Mbagathi Rd) or Garden Estate.';
	}
	// "When?" comes before payment.
	if ( $block['blockName'] === 'woocommerce/checkout-fields-block' && ! empty( $block['innerBlocks'] ) ) {
		$names = array_column( $block['innerBlocks'], 'blockName' );
		$info  = array_search( 'woocommerce/checkout-additional-information-block', $names, true );
		$pay   = array_search( 'woocommerce/checkout-payment-block', $names, true );
		if ( $info !== false && $pay !== false && $info > $pay ) {
			$moved = array_splice( $block['innerBlocks'], $info, 1 );
			array_splice( $block['innerBlocks'], $pay, 0, $moved );
		}
	}
	return $block;
} );

/**
 * Order times: ASAP while the kitchen is open (and not in its last half hour), then every 30 minutes
 * until closing, today; after hours and on Sundays, the next day they open.
 */
function un_order_times() {
	$now  = new DateTime( 'now', wp_timezone() );
	$day  = clone $now;
	$open = fn( DateTime $d ) => ! in_array( (int) $d->format( 'w' ), UN_CLOSED_DAYS, true );
	$out  = [];
	$last = DateTime::createFromFormat( 'Y-m-d H:i', $now->format( 'Y-m-d' ) . ' ' . UN_CLOSE, wp_timezone() )->modify( '-30 minutes' );
	if ( ! $open( $now ) || $now > $last ) {
		do {
			$day->modify( '+1 day' );
		} while ( ! $open( $day ) );
		$day->setTime( ...array_map( 'intval', explode( ':', UN_OPEN ) ) );
		$prefix = ( $day->format( 'Y-m-d' ) === ( clone $now )->modify( '+1 day' )->format( 'Y-m-d' ) ? 'Tomorrow' : $day->format( 'l' ) ) . ' at ';
		$start  = clone $day;
		$start->modify( '+30 minutes' );
	} else {
		$out['asap'] = 'As soon as possible (about 45–60 min)';
		$prefix      = 'Today at ';
		$start       = DateTime::createFromFormat( 'Y-m-d H:i', $now->format( 'Y-m-d' ) . ' ' . UN_OPEN, wp_timezone() )->modify( '+30 minutes' );
		$min         = ( clone $now )->modify( '+45 minutes' );
		while ( $start < $min ) {
			$start->modify( '+30 minutes' );
		}
	}
	$end = DateTime::createFromFormat( 'Y-m-d H:i', $start->format( 'Y-m-d' ) . ' ' . UN_CLOSE, wp_timezone() )->modify( '-30 minutes' );
	for ( $t = clone $start; $t <= $end; $t->modify( '+30 minutes' ) ) {
		$out[ $t->format( 'Y-m-d H:i' ) ] = $prefix . $t->format( 'g:i a' );
	}
	return $out;
}
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) return;
	$times = un_order_times();
	woocommerce_register_additional_checkout_field( [
		'id'       => 'un/when',
		'label'    => 'When do you want it?',
		'location' => 'order',
		'type'     => 'select',
		'required' => true,
		'options'  => array_map( fn( $v, $l ) => [ 'value' => (string) $v, 'label' => $l ], array_keys( $times ), $times ),
	] );
	woocommerce_register_additional_checkout_field( [
		'id'       => 'un/contactless',
		'label'    => 'No-contact delivery: leave it at the door or gate and call me',
		'location' => 'order',
		'type'     => 'checkbox',
	] );
} );

// The Patty Party Pack comes with free delivery (their offer on Instagram, May and July 2026: PLACEHOLDER, confirm it still runs).
add_filter( 'woocommerce_package_rates', function ( $rates, $package ) {
	$has_pack = false;
	foreach ( $package['contents'] ?? [] as $item ) {
		if ( ( $item['data'] ?? null ) && $item['data']->get_slug() === 'patty-party-pack' ) $has_pack = true;
	}
	if ( ! $has_pack ) return $rates;
	foreach ( $rates as $rate ) {
		if ( $rate->get_method_id() === 'flat_rate' ) {
			$rate->set_cost( 0 );
			$rate->set_label( $rate->get_label() . ' (free with the Patty Party Pack)' );
		}
	}
	return $rates;
}, 10, 2 );

// After a refused checkout (e.g. a shake with delivery), the customer switches to pickup and tries again on the
// same draft order. WooCommerce swaps the shipping line with remove_order_items(), whose DELETE … USING query the
// SQLite database of the Playground demo silently skips, so the order kept the old method. Make sure the saved
// shipping line matches the customer's choice.
add_action( 'woocommerce_store_api_checkout_order_processed', function ( $order ) {
	$chosen = WC()->session ? array_values( (array) WC()->session->get( 'chosen_shipping_methods', [] ) ) : [];
	if ( ! $chosen || ! WC()->cart || ! WC()->cart->needs_shipping() ) return;
	$have = array_values( array_map( fn( $m ) => $m->get_name(), $order->get_shipping_methods() ) );
	$want = [];
	foreach ( WC()->shipping()->get_packages() as $i => $pkg ) {
		if ( isset( $pkg['rates'][ $chosen[ $i ] ?? '' ] ) ) $want[] = $pkg['rates'][ $chosen[ $i ] ]->get_label();
	}
	if ( $want && $have !== $want ) {
		// One item at a time: remove_order_items() uses a DELETE … USING query the SQLite layer of the demo skips.
		foreach ( array_keys( $order->get_shipping_methods() ) as $item_id ) {
			$order->remove_item( $item_id );
		}
		WC()->checkout()->create_order_shipping_lines( $order, $chosen, WC()->shipping()->get_packages() );
		$order->calculate_totals();
		$order->save();
	}
}, 1 );

// Shakes, lemonades and hot drinks are only made at Garden Estate: those orders must be Garden Estate pickup.
add_action( 'woocommerce_store_api_checkout_update_order_from_request', function ( $order ) {
	$dinein = array_filter( $order->get_items(), fn( $i ) => un_is_dinein( $i->get_product_id() ) );
	if ( ! $dinein ) return;
	// Read the choice from the cart: a draft order kept from an earlier attempt can still hold the old shipping line.
	$garden = false;
	$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods', [] ) : [];
	foreach ( WC()->shipping()->get_packages() as $i => $pkg ) {
		$rate = $pkg['rates'][ $chosen[ $i ] ?? '' ] ?? null;
		if ( $rate && $rate->get_method_id() === 'pickup_location' && str_contains( (string) ( $rate->get_meta_data()['pickup_location'] ?? '' ), 'Garden Estate' ) ) $garden = true;
	}
	if ( ! $garden ) {
		throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'un_dinein', 'Shakes, lemonades and hot drinks are made at Garden Estate only. Choose Pickup → Garden Estate, or remove ' . implode( ', ', array_map( fn( $i ) => $i->get_name(), $dinein ) ) . ' for delivery.', 400 );
	}
} );

function un_order_code( WC_Order $order ) {
	return 'UN-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function un_order_when( WC_Order $order ) {
	$v = (string) $order->get_meta( '_wc_other/un/when' );
	if ( $v === 'asap' ) return 'As soon as possible';
	$t = DateTime::createFromFormat( 'Y-m-d H:i', $v, wp_timezone() );
	return $t ? $t->format( 'D j M, g:i a' ) : $v;
}
function un_order_pickup( WC_Order $order ) {
	foreach ( $order->get_shipping_methods() as $m ) {
		if ( $m->get_method_id() === 'pickup_location' ) return (string) $m->get_meta( 'pickup_location' ) ?: 'Pickup';
	}
	return '';
}
function un_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Uncle Nene\'s, I just ordered online (' . un_order_code( $order ) . '):' ];
	foreach ( $order->get_items() as $item ) {
		$opts = [];
		foreach ( $item->get_meta_data() as $m ) {
			$d = $m->get_data();
			if ( $d['key'][0] !== '_' && ! in_array( $d['key'], [ 'style', 'flavour', 'drink' ], true ) ) $opts[] = $d['key'] . ': ' . wp_strip_all_tags( (string) $d['value'] );
		}
		$lines[] = '• ' . $item->get_quantity() . ' × ' . html_entity_decode( $item->get_name(), ENT_QUOTES ) . ' – ' . un_money( $item->get_total() ) . ( $opts ? "\n   " . implode( ' · ', $opts ) : '' );
	}
	$pickup  = un_order_pickup( $order );
	$lines[] = $pickup ? 'Pickup: ' . $pickup : $order->get_shipping_method() . ' – ' . un_money( $order->get_shipping_total() );
	$lines[] = 'Total: ' . un_money( $order->get_total() ) . ', ' . $order->get_payment_method_title();
	$lines[] = 'When: ' . un_order_when( $order );
	$address = trim( implode( ', ', array_filter( [ $order->get_billing_address_1(), $order->get_billing_address_2(), $order->get_billing_city() ] ) ) );
	if ( $address && ! $pickup ) $lines[] = 'Deliver to: ' . $address;
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return un_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) { // phpcs:ignore
		return $content;
	}
	$pickup = un_order_pickup( $order );
	$where  = str_contains( $pickup, 'Garden' ) ? 'Come to our counter at Amani Food Court, Berea Road, Garden Estate.' : 'Call ' . UN_PHONE . ' when you reach our Ngummo window on Mbagathi Road.';
	return $content . '<div class="un-thanks"><p class="un-thanks__code">Order number <strong>' . esc_html( un_order_code( $order ) ) . '</strong></p><p class="un-thanks__when">' . esc_html( ( $pickup ? 'Pickup at ' . $pickup . ' · ' : 'Delivery · ' ) . un_order_when( $order ) ) . '</p><ol><li>We confirm on WhatsApp or by phone in a few minutes.</li><li>The kitchen fires your order: patties on the grill, fries in the fryer.</li><li>' . ( $pickup ? esc_html( $where ) : 'Our rider brings it to your door. Pay by M-Pesa or cash.' ) . '</li></ol><a class="wp-element-button un-wa-btn" href="' . esc_attr( un_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">' . UN_WA_ICON . 'Send my order to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order number:</strong> ' . esc_html( un_order_code( $order ) ) . '<br><strong>When:</strong> ' . esc_html( un_order_when( $order ) ) . '</p>';
} );

// Staff edit the menu extras on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_un_line', 'label' => 'Tagline', 'description' => 'Short line above the name, e.g. "Grass-fed beef · melted cheese".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_un_badge', 'label' => 'Badge', 'description' => 'Short label on the photo, e.g. "Fan favourite".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_un_portion', 'label' => 'Portion', 'description' => 'e.g. "Burger + fries".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_un_opts', 'label' => 'Options', 'description' => 'Comma-separated: double, extras, sides, dip.', 'desc_tip' => true ] );
	woocommerce_wp_checkbox( [ 'id' => '_un_dinein', 'label' => 'Garden Estate only', 'description' => 'Made at Garden Estate: dine-in or Garden Estate pickup, no delivery.', 'cbvalue' => 'yes' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_un_ingredients', 'label' => 'What\'s in it', 'rows' => 5, 'description' => 'One per line.' ] );
	woocommerce_wp_textarea_input( [ 'id' => '_un_allergens', 'label' => 'Allergens', 'rows' => 4, 'description' => 'One per line.' ] );
	woocommerce_wp_text_input( [ 'id' => '_un_reel', 'label' => 'Instagram post link' ] );
	echo '<p class="form-field"><em>Menu filters = product tags (beef, chicken, fish, bacon, cheese, vegetarian). Style or flavour prices = Variations. Mark an item sold out with Inventory → Out of stock.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_un_line', '_un_badge', '_un_portion', '_un_opts' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	foreach ( [ '_un_ingredients', '_un_allergens' ] as $k ) {
		if ( isset( $_POST[ $k ] ) ) $product->update_meta_data( $k, sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ); // phpcs:ignore
	}
	$product->update_meta_data( '_un_dinein', isset( $_POST['_un_dinein'] ) ? 'yes' : 'no' ); // phpcs:ignore
	if ( isset( $_POST['_un_reel'] ) ) $product->update_meta_data( '_un_reel', esc_url_raw( wp_unslash( $_POST['_un_reel'] ) ) ); // phpcs:ignore
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode']  = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['state']     = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['address_1'] = [ 'label' => 'Building / estate & street' ];
	$locale['KE']['address_2'] = [ 'label' => 'House or office number, gate, landmark' ];
	$locale['KE']['city']      = [ 'label' => 'Area (e.g. Kilimani, Roysambu)' ];
	$locale['KE']['phone']     = [ 'required' => true ];
	return $locale;
} );

add_filter( 'gettext', function ( $text, $original, $domain ) {
	if ( $domain !== 'woocommerce' ) return $text;
	return [
		'Related products'  => 'Goes well with',
		'Continue shopping' => 'Back to the menu',
		'Shop'              => 'Menu',
		'Shipping:'         => 'Delivery:',
		'Shipping address'  => 'Delivery address',
	][ $original ] ?? $text;
}, 10, 3 );
add_filter( 'ngettext', fn( $text, $single, $plural, $number, $domain ) => $domain === 'woocommerce' && $single === '%s has been added to your cart.' ? '%s has been added to your order.' : $text, 10, 5 );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

add_action( 'wp_head', function () {
	if ( has_site_icon() ) return;
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#121212\">\n";
} );

// Shortcode blocks: run the shortcode as is (the block's automatic paragraphs break the grids).
add_filter( 'pre_render_block', fn( $pre, $block ) => ( $block['blockName'] ?? '' ) === 'core/shortcode' ? do_shortcode( trim( $block['innerHTML'] ) ) : $pre, 10, 2 );
// Shortcodes inside custom HTML blocks on the templates.
add_filter( 'render_block_core/html', fn( $c ) => str_contains( $c, '[un_' ) ? do_shortcode( $c ) : $c );

// Templates use root-relative links ("/menu/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) return $content;
	return preg_replace( '#\b(href|src|action|poster)="/(?!/)#', '$1="' . $home, $content );
} );
